<?php
// (A) LOAD PHPWORD
require "vendor/autoload.php";
$pw = new \PhpOffice\PhpWord\PhpWord();




$variable1 = "<h1>HELLO WORLD!</h1>";

 
// (B) ADD HTML CONTENT
$section = $pw->addSection();
$html = "$variable1";
$html .= "<p>This is a paragraph of random text</p>";
$html .= "<ul>
<li><strong>(A) </strong>Start by including the PHPWord library, and creating the object.
</li><li><strong>(B) </strong>Add a new section to the DOCX document, then simply insert your HTML code.
</li><li><strong>(C &amp; D) </strong>Output the file, and that’s it!
</li></ul>";
\PhpOffice\PhpWord\Shared\Html::addHtml($section, $html, false, false);
 
// (C) SAVE TO DOCX ON SERVER
// $pw->save("convert.docx", "Word2007");
 
// (D) OR FORCE DOWNLOAD
header("Content-Type: application/octet-stream");
header("Content-Disposition: attachment;filename=\"convert.docx\"");
$objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($pw, "Word2007");
$objWriter->save("php://output");


?>